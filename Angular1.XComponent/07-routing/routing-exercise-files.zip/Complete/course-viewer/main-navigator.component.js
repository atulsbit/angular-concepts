(function () {
    'use strict';

    angular.module('courseViewer').component('mainNavigator', {
        templateUrl: 'course-viewer/main-navigator.component.html'
    });
})();
