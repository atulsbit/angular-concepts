(function () {
    'use strict';

    angular.module('courseViewer').component('courseNavigator', {
        templateUrl: 'course-viewer/course/course-navigator.component.html'
    });
})();
