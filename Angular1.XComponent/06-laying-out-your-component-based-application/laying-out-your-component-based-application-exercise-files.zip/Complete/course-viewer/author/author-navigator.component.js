(function () {
    'use strict';

    angular.module('courseViewer').component('authorNavigator', {
        templateUrl: 'course-viewer/author/author-navigator.component.html'
    });
})();
