(function () {
    'use strict';

    angular.module('courseViewer').component('courseAuthorInfo', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/course/course-author-info.component.html'
    });
})();
